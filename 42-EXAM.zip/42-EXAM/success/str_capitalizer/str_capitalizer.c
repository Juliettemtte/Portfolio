#include <unistd.h>

void    ft_putchar(int c)
{
    write(1, &c, 1);
}

int main(int argc, char **argv)
{
    int i = 1;

    if (argc > 1)
    {
        while (i < argc)
        {
            if (*argv[i] >= 'a' && *argv[i] <= 'z')
                ft_putchar(*argv[i] - 32);
            else
                ft_putchar(*argv[i]);
            argv[i]++;
            while (*argv[i])
            {
                if ((*(argv[i] - 1) == 32 || *(argv[i] - 1) == 9) && *argv[i] >= 'a' && *argv[i] <= 'z')
                    ft_putchar(*argv[i] - 32);
                else if ((*(argv[i] - 1) != 32 && *(argv[i] - 1) != 9) && *argv[i] >= 'A' && *argv[i] <= 'Z')
                    ft_putchar(*argv[i] + 32);
                else
                    ft_putchar(*argv[i]);
                argv[i]++;
            }
            if (*argv[i] == '\0')
                write(1, "\n", 1);
            i++;
        }
    }
    else
        write(1, "\n", 1);
    return (0);
}
