#include <unistd.h>
#include <stdlib.h>

void    ft_putstr(char *str)
{
    while (*str)
        write(1, str++, 1);
}

void    rev_wstr(char *str)
{
    int     i = 0;
    int     j = 0;
    int     k = 0;
    char    **words;

    // First, count the number of words
    while (str[i])
    {
        while (str[i] && (str[i] == ' ' || str[i] == '\t'))
            i++;
        if (str[i] && str[i] != ' ' && str[i] != '\t')
            j++;
        while (str[i] && str[i] != ' ' && str[i] != '\t')
            i++;
    }

    words = (char **)malloc(sizeof(char *) * (j + 1));
    if (!words)
        return;

    i = 0;
    j = 0;
    while (str[i])
    {
        while (str[i] && (str[i] == ' ' || str[i] == '\t'))
            i++;
        if (str[i] && str[i] != ' ' && str[i] != '\t')
        {
            k = i;
            while (str[i] && str[i] != ' ' && str[i] != '\t')
                i++;
            words[j] = (char *)malloc(i - k + 1);
            if (!words[j])
                return;
            int l = 0;
            while (k < i)
                words[j][l++] = str[k++];
            words[j][l] = '\0';
            j++;
        }
    }
    words[j] = NULL;

    for (int m = j - 1; m >= 0; m--)
    {
        ft_putstr(words[m]);
        if (m > 0)
            write(1, " ", 1);
    }
    write(1, "\n", 1);

    for (int n = 0; n < j; n++)
        free(words[n]);
    free(words);
}

int     main(int argc, char **argv)
{
    if (argc != 2)
    {
        write(1, "\n", 1);
        return (0);
    }
    rev_wstr(argv[1]);
    return (0);
}
