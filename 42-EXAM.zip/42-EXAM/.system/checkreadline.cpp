#include <iostream>
#include <readline/readline.h>

int main()
{
    std::cout << "Hello World" << std::endl;
    return 0;
}